# Stoned Loading Screen

A simple loading screen resource for FiveM.

<hr>

## Features

- Loading screen image

- Music player
    - Play videos directly from youtube.
    - Pause and unpause and control volume on the fly.
- Backgrounds
    - Rotating backgrounds with fade in and fade out.


<hr>
